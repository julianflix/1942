# Game Module Documentation

## Overview
The `Game` class is the core of a 2D shooter game, handling game logic, rendering, and interactions. It manages player controls, enemy AI, bullet physics, power-ups, and level progression. The game uses `pygame` for rendering and input handling, with an async loop for smooth updates.

---

## Key Classes

### `Game`
**Responsibility**: Manages the game state, rendering, and interactions.

**Key Methods**:
- `__init__(self, level_files)`: Initializes game components (player, enemies, bullets, etc.).
- `update(self, dt, dt_ms)`: Updates game state (player movement, collisions, enemy behavior).
- `render(self)`: Renders the game screen, including HUD and effects.
- `next_level_or_win(self)`: Transitions to the next level or triggers a win condition.
- `game_over(self)`: Handles game over state and displays the "GAME OVER" screen.

**Attributes**:
- `player_sprite`: The player's ship.
- `enemies`: List of enemy sprites.
- `player_bullets`: Player's bullet projectiles.
- `enemy_bullets`: Enemy's bullet projectiles.
- `drops`: Power-up items (health, ammo, etc.).
- `fx`: Explosion effects.
- `bg`: Background manager for scrolling or static backgrounds.

---

## Key Functions

### `discover_level_files(level_dir=LEVELS_DIR)`
**Purpose**: Discovers level files in the `levels` directory.

**Inputs**:
- `level_dir`: Directory path containing level files (default: `LEVELS_DIR`).

**Returns**:
- Sorted list of level file paths (e.g., `["level1.txt", "level2.txt", ...]`).

**Usage**:
```python
level_files = discover_level_files()
```

---

### `main_async()`
**Purpose**: Entry point for the game, handles command-line arguments and starts the game loop.

**Arguments**:
- `--level`: Starting level number (default: 1).

**Usage**:
```bash
python game.py --level 3
```

---

## Configuration and Environment

### Configuration Files
- **Level Files**: Text files in `./levels/` (e.g., `level1.txt`) define enemy patterns and level layout.
- **Constants**: Global variables like `BLACK`, `WHITE`, `GRAY` are defined elsewhere (e.g., in a `constants.py` file).

### Environment Variables
- `LEVELS_DIR`: Directory containing level files (default: `./levels/`).

---

## Game Mechanics

### Player Controls
- **Movement**: Arrow keys or touch controls.
- **Shooting**: Spacebar or touch fire button.
- **Power-Ups**:
  - `health`: Restores 1 life.
  - `ammo`: Adds 50 bullets.
  - `enhanced`: Grants rapid-fire mode for 5 seconds.
  - `fan`: Enables diagonal shooting for 5 seconds.

### Collision Detection
- **Player vs Enemies**: Triggers damage and explosions.
- **Bullets vs Enemies**: Destroys enemies and drops power-ups.
- **Safe Zone**: When the player reaches the bottom of the screen, the game advances to the next level.

---

## Usage Examples

### Starting the Game
```bash
python game.py --level 2
```
Starts the game at level 2.

### Adding a New Level
1. Create a new `levelX.txt` file in `./levels/`.
2. Define enemy patterns and layout in the file.
3. The game will automatically detect and use the new level.

---

## Dependencies

- **pygame**: For rendering and input handling.
- **asyncio**: For asynchronous game loop.
- **glob**: For discovering level files.
- **random**: For power-up spawning.

---

## Code Structure

```
game.py
├── Game class (main game logic)
├── PlayerSprite class (player controls, shooting)
├── Enemy classes (various enemy types)
├── Bullet class (player and enemy projectiles)
├── Drop class (power-ups)
├── Explosion class (visual effects)
└── discover_level_files() (level file discovery)
```

---

## Key Constants

| Name         | Value       | Purpose                     |
|--------------|-------------|-----------------------------|
| `BLACK`      | `(0, 0, 0)` | Background color            |
| `WHITE`      | `(255, 255, 255)` | HUD text color       |
| `GRAY`       | `(128, 128, 128)` | Debug info color     |
| `RED`        | `(255, 0, 0)` | Game over text color      |
| `GREEN`      | `(0, 255, 0)` | Win screen text color     |

---

## Async Game Loop
The game uses `asyncio` for non-blocking updates:
```python
async def main_async():
    game = Game(...)
    await game.run()
```
- `game.run()` handles the main loop, updating and rendering the game state.
- `update()` processes game logic (movement, collisions, etc.).
- `render()` draws the current state to the screen.

---

## Example Level File Format
A `level1.txt` might look like:
```
# Enemy pattern: x, y, speed, type
100, 50, 2, basic
200, 50, 1, fast
```
This defines two enemies at positions (100, 50) and (200, 50) with different speeds.

---

## Debugging
- **Debug Mode**: Press `D` to show debug info (enemy count, bullet counts, etc.).
- **HUD**: Displays lives, power-up timers, and pause messages.

---

This documentation provides a high-level overview of the game's architecture, mechanics, and configuration. For deeper insights, refer to the source code and associated files in the repository.