# Game Documentation

## Overview
The provided code is a 2D shooter game implementation using Python and Pygame. The game features level progression, enemy spawning, power-ups, and collision detection. The core logic is encapsulated in the `Game` class, which manages the game loop, rendering, and interactions between game entities.

---

## Key Classes

### `Game`
The central game class handling:
- **Game loop** (`run()`): Manages event handling, updates, and rendering.
- **State management**: Tracks player lives, power-ups, and game progression.
- **Entity interactions**: Handles collisions between bullets, enemies, and the player.

**Key Methods:**
- `run()`: Main game loop with event handling and state updates.
- `update(dt, dt_ms)`: Updates game logic (enemy movement, collisions, etc.).
- `render()`: Draws all game elements (background, sprites, HUD).
- `handle_events()`: Processes user input and game events.

**Attributes:**
- `player_sprite`: The player's ship (instance of a sprite class).
- `enemies`: Group of enemy sprites.
- `timeline`: Manages enemy spawning and safe zone activation.
- `bg`: Background object for scrolling levels.

---

### `Enemy` Subclasses
- `ShooterEnemy`: Enemy that fires bullets.
- Other enemies: Likely handle different behaviors (e.g., movement patterns).

**Example:**
```python
class ShooterEnemy(pygame.sprite.Sprite):
    def update(self, dt, bullets_group):
        # Handle shooting logic
```

---

### `Drop` and `Explosion`
- `Drop`: Power-up items (e.g., health, ammo, enhanced abilities).
- `Explosion`: Visual effect for enemy destruction.

---

## Key Functions

### `discover_level_files(level_dir=LEVELS_DIR)`
- **Purpose**: Discovers level files in the specified directory.
- **Output**: Sorted list of level file paths (e.g., `level1.txt`, `level2.txt`).

### `main()`
- **Purpose**: Entry point for the game.
- **Usage**:
  ```bash
  python game.py --level 3
  ```
  Starts the game at level 3.

---

## Configuration

### Constants
- **FPS**: Frame rate (controlled via `clock.tick(FPS)`).
- **Colors**: `BLACK`, `WHITE`, `RED`, `GREEN`, etc., used for rendering.
- **Power-up Timings**: `SAFE_ZONE_TAIL_MS`, `DROP_CHANCE`, etc.

### Level Files
- Located in `LEVELS_DIR` (default: `./levels`).
- Format: Text files defining level structure (e.g., enemy positions, background segments).

---

## Environment Variables
- **LEVELS_DIR**: Directory containing level files (default: `./levels`).
- **FPS**: Controls game speed (set in code).

---

## Usage Examples

### Start the Game
```bash
python game.py
```
Starts the game at level 1.

### Specify a Level
```bash
python game.py --level 5
```
Starts the game at level 5.

### Controls
- **Arrow Keys**: Move player.
- **Spacebar**: Shoot.
- **P**: Pause/resume.
- **F**: Spawn a "fan" power-up at the player's position.

---

## Key Game Mechanics

### Power-Ups
- **Enhanced**: Multi-shot bullets for a duration.
- **Fan**: Diagonal shooting for a duration.
- **Health**: Increases player lives.
- **Ammo**: Adds bullets to the player's reserve.

### Safe Zone
- Activated after all enemies are defeated.
- Player must reach the safe zone to progress to the next level.

### Collision Detection
- **Player vs. Enemies**: Triggers damage and explosions.
- **Bullets vs. Enemies**: Destroys enemies and drops power-ups.

---

## Code Structure Highlights

### Game Loop Flow
1. **Event Handling**: Processes input (keyboard, quit).
2. **State Updates**: Moves sprites, checks collisions, updates timers.
3. **Rendering**: Draws background, sprites, and HUD.

### Entity Management
- **Enemies**: Updated via `update(dt)` methods.
- **Bullets**: Managed as sprite groups (`player_bullets`, `enemy_bullets`).
- **Power-Ups**: Spawned randomly on enemy destruction.

---

## Dependencies
- **Pygame**: For rendering and event handling.
- **Standard Libraries**: `time`, `random`, `os`, `glob` for file management and timing.

---

## Example Level File (`level1.txt`)
```txt
# Enemy positions and types
enemy1: type=shooter, x=100, y=50
enemy2: type=basic, x=300, y=100
```

---

## Notes
- **Performance**: Uses `pygame.sprite.Group` for efficient collision detection.
- **Extensibility**: New enemy types or power-ups can be added by subclassing existing classes.
- **Debug Mode**: Enabled via `F1` key, showing debug HUD (enemy counts, etc.).