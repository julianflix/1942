# Game Documentation

## Overview
This is a 2D shooter game inspired by classic arcade titles like 1942. The game features a player ship, enemies, bullets, power-ups, and a scrolling background. The code uses Pygame for rendering and input handling, with an async game loop for smooth animations and transitions.

## Key Components

### 1. **Main Game Class: `Game`**
The central class that manages the game state, rendering, and interactions.

#### Key Methods:
- `__init__`: Initializes game components (player, enemies, bullets, background, etc.).
- `update`: Async method that handles game logic (movement, collisions, power-ups).
- `render`: Draws all game elements to the screen.
- `handle_input`: Processes keyboard, mouse, and touch inputs.
- `next_level_or_win`: Transitions to the next level or ends the game.

#### Key Attributes:
- `player_sprite`: The player's ship object.
- `enemies`: List of enemy sprites.
- `player_bullets`: List of bullets fired by the player.
- `enemy_bullets`: List of bullets fired by enemies.
- `drops`: Power-up items that appear after defeating enemies.
- `fx`: Explosion effects.
- `bg`: Background object (scrolling or static).

---

### 2. **Player Sprite: `PlayerSprite`**
Controls the player's ship, including movement, shooting, and power-ups.

#### Key Methods:
- `update`: Handles movement and shooting.
- `shoot`: Fires bullets based on player input.
- `damage`: Reduces player health and triggers invincibility.
- `grant_enhanced`: Grants a temporary bullet spread power-up.
- `grant_fan`: Grants diagonal shooting for a limited time.

#### Power-Ups:
- `enhanced`: Wider bullet spread for 5 seconds.
- `fan`: Diagonal shooting for 5 seconds.
- `health`: Increases player lives.
- `ammo`: Increases bullet capacity.

---

### 3. **Enemy Classes**
Various enemy types with different behaviors.

#### Example:
- `ShooterEnemy`: Fires bullets periodically.
- `Enemy`: Base class for all enemies, handling movement and collision.

#### Key Features:
- Enemies spawn from level files.
- Collisions with bullets or the player trigger damage.
- Defeated enemies drop power-ups.

---

### 4. **Bullet System**
Handles both player and enemy bullets.

#### Key Features:
- **Player Bullets**: Fired on key press or auto-fire.
- **Enemy Bullets**: Fired by `ShooterEnemy` at intervals.
- **Collision Detection**: Checks for hits against enemies and the player.

---

### 5. **Power-Ups (Drops)**
Collectible items that appear after defeating enemies.

#### Types:
- `health`: +1 life.
- `ammo`: +50 bullets.
- `enhanced`: Temporary bullet spread.
- `fan`: Temporary diagonal shooting.

---

### 6. **Background System**
Manages scrolling or static backgrounds.

#### Key Methods:
- `update`: Updates background position.
- `draw`: Renders the background to the screen.

---

### 7. **Game Loop**
The async `update` method handles:
- Input processing
- Movement and collision checks
- Power-up collection
- Level transitions
- Rendering

---

## Configuration and Constants

### Game Settings
```python
PLAYER_SPEED = 300  # Pixels per second
BULLET_SPEED = 500
ENEMY_SPEED = 100
ENEMY_SPAWN_INTERVAL = 2.0  # Seconds
DROP_CHANCE = 0.3  # 30% chance for power-ups
```

### Colors
```python
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
GRAY = (128, 128, 128)
```

### Power-Up Weights
```python
DROP_WEIGHTS = {
    "health": 1,
    "ammo": 2,
    "enhanced": 1,
    "fan": 1
}
```

---

## Level System
- **Level Files**: Text files in `./levels/` (e.g., `level1.txt`).
- **Loading**: `discover_level_files()` finds and sorts level files.
- **Progression**: `next_level_or_win()` transitions to the next level or ends the game.

---

## Input Handling
Supports multiple input types:
- **Keyboard**: WASD or arrow keys for movement, SPACE for shooting.
- **Mouse**: Click to shoot (optional).
- **Touch**: Mobile-friendly controls via `TouchControls`.

---

## Usage Examples

### Starting the Game
```bash
python game.py --level 1
```

### Level File Format
Each `levelX.txt` defines enemy positions and patterns. Example:
```
enemy1,100,200
enemy2,300,150
```

### Power-Up Collection
When the player collides with a power-up:
```python
# Example: Collecting a "health" drop
self.player_sprite.lives = min(9, self.player_sprite.lives + 1)
```

---

## Key Functions

### `shoot(time, bullets_group)`
Fires bullets from the player. Handles cooldown and ammo limits.

### `damage(damage_amount)`
Reduces player/enemy health. Returns `True` if the entity is destroyed.

### `grant_enhanced(now)`
Activates the enhanced bullet spread for 5 seconds.

### `grant_fan(now)`
Activates diagonal shooting for 5 seconds.

---

## Environment Variables
- `LEVELS_DIR`: Directory containing level files (default: `./levels/`).

---

## Dependencies
- `pygame`: For rendering and input handling.
- `asyncio`: For async game loop.
- `glob`: For discovering level files.
- `random`: For power-up spawning.

---

## File Structure (Repository Context)
```
game.py
levels/
  level1.txt
  level2.txt
  ...
utils.py  # (Assumed helper functions)
```

---

## Future Improvements
- Add sound effects and music.
- Implement more enemy types and boss battles.
- Add a pause menu and settings screen.
- Optimize power-up spawning logic.

---

This documentation provides a high-level overview of the game's architecture, key components, and configuration. For deeper insights, explore the source code for specific implementations.