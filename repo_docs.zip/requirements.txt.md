# `requirements.txt` Documentation

The `requirements.txt` file specifies the Python package dependencies required to run the project. It is used by `pip` to install all necessary libraries for development and execution.

---

## Overview

This file lists the external Python packages required by the game application. It ensures consistency across environments by pinning specific versions of dependencies.

---

## Key Dependencies

### 1. `pygame>=2.5.2`
- **Purpose**: Core library for game development in Python.
- **Features**:
  - Graphics rendering
  - Sound and music handling
  - Input device support (keyboard, mouse, etc.)
  - Collision detection
- **Version**: Minimum version `2.5.2` (latest stable recommended).

### 2. `pygbag`
- **Purpose**: Enables running Pygame applications in web browsers via WebAssembly (WASM).
- **Features**:
  - WebAssembly compilation for browser compatibility
  - Integration with Pygame's API for web deployment
- **Usage**: Required for building or running the game in a web environment.

---

## Usage Examples

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Verify Installation
```bash
pip show pygame pygbag
```

---

## Configuration Implications

- **Environment Setup**: Ensure Python 3.x is installed. The project uses `asyncio`, so a modern Python version (3.7+) is required.
- **Web Deployment**: `pygbag` is necessary for packaging the game as a web application. Without it, browser-based execution will fail.
- **Version Compatibility**: The pinned version of `pygame` ensures stability. Upgrading may require testing for compatibility.

---

## Relationship with Other Files

- **`main_async.py`**: Uses `pygbag` for async game loops and web deployment.
- **`build/version.txt`**: Tracks the project version (0.9.2), separate from dependency versions.
- **Game Logic**: Relies on `pygame` for all core mechanics (e.g., `PlayerSprite`, `Enemy`, bullet physics).

---

## Best Practices

- **Lock Versions**: Always use pinned versions in `requirements.txt` to avoid unexpected behavior from updates.
- **Environment Isolation**: Use virtual environments (`venv`) to manage dependencies per project.
- **Web Builds**: For web deployment, ensure `pygbag` is installed and configured correctly.