# 1942-lite Documentation

## Overview
`1942-lite` is a Pygame-based top-down shooter game with support for custom level design, dynamic asset loading, and procedural animations. The project structure and configuration allow for easy expansion and customization.

---

## Key Features

### 1. **Dynamic Asset Loading**
- **PNG Sprites**: Supports custom graphics for player/enemies.
  - Required assets: `player.png`, `enemy_shooter.png`, `enemy_kamikaze.png`, `enemy_big.png`
  - Fallback: Default shapes (triangles, circles) when assets are missing
- **Explosion Animations**: 
  - Uses `assets/explosion_0.png` to `assets/explosion_5.png`
  - Procedural fallback if animation frames are missing

### 2. **Multi-Level System**
- **Level Files**: ASCII-based level definitions in `levels/`
  - Format: Each character represents a game object
  - Example:
    ```
    S K B
    . . .
    ```
  - `S` = Shooter enemy, `K` = Kamikaze, `B` = Big enemy, `.` = Empty space
- **Auto-Discovery**: Loads all `levels/level*.txt` files in numerical order
- **Safe Zone**: Progression triggers when player reaches designated safe area (implementation details in game code)

---

## Repository Structure

```
1942-lite/
├── main.py                  # Game entry point
├── assets/                  # Sprite/explosion animations
│   ├── player.png
│   ├── enemy_shooter.png
│   └── explosion_0.png...5.png
├── levels/                  # Level definitions
│   ├── level1.txt
│   ├── level2.txt
│   └── ... (up to level9.txt)
└── README.md                # This document
```

---

## Configuration & Usage

### 1. **Requirements**
```bash
pip install pygame>=2.5.2
```

### 2. **Running the Game**
```bash
python main.py
```

### 3. **Creating New Levels**
- Add a new file to `levels/` named `levelX.txt` (X = next number)
- Use ASCII characters to define enemies:
  - `S` - Shooter (standard enemy)
  - `K` - Kamikaze (suicide bomber)
  - `B` - Big (larger enemy)
  - `.` or space - Empty tile

**Example level1.txt**:
```
S S S
. . .
B K S
```

---

## Code Structure & Relationships

### 1. **Main Game Logic**
- `main.py` contains:
  - Game loop with Pygame integration
  - Level loading system (reads `levels/level*.txt`)
  - Player/enemy control systems
  - Collision detection and scoring

### 2. **Asset Management**
- `assets/` directory is scanned at startup
- Fallback rendering logic in game code for missing assets

### 3. **Level Parsing**
- Automatic discovery of `levels/level*.txt`
- Each level file is parsed into a grid-based enemy spawning system
- Safe zone detection logic (implementation details in game code)

---

## Controls

| Action         | Key        | Description                  |
|----------------|------------|------------------------------|
| Move Player    | Arrow Keys | WASD also supported          |
| Shoot          | Space      | Fires bullets                |
| Pause          | P          | Toggles game pause           |
| Toggle Debug   | F1         | Shows/hides debug information|
| Quit           | Esc / Q    | Exits the game               |

---

## Customization Tips

### Adding New Assets
1. Place PNG files in `assets/`
2. Ensure filenames match expected names:
   - `player.png` (player sprite)
   - `enemy_shooter.png` (standard enemy)
   - `enemy_kamikaze.png` (suicide enemy)
   - `enemy_big.png` (large enemy)
   - `explosion_0.png` to `explosion_5.png` (animation frames)

### Creating New Levels
1. Create `levels/levelX.txt` where X is next number
2. Use ASCII characters to define enemy positions
3. Add to `levels/` directory - game auto-detects new levels

---

## Implementation Notes

- **Level Progression**: The game advances to the next level when the player reaches the "Safe Zone" (specific coordinates in level files)
- **Enemy Behavior**: 
  - `S` enemies move horizontally
  - `K` enemies fly toward the player
  - `B` enemies are larger and slower
- **Collision System**: Detects player-enemy and bullet-enemy interactions

---

## Example Level File (level1.txt)
```
S S S
. . .
B K S
```
This would create:
- 3 shooter enemies in the top row
- Empty space in the middle row
- 1 big enemy, 1 kamikaze, and 1 shooter in the bottom row

---

## Debug Mode
Enabled with F1 key:
- Shows player position
- Displays enemy spawn points
- Shows collision boundaries
- Displays score and level information

---

## Known Limitations
- Level files must be named `levelX.txt` with X as integer
- Explosion animations require exactly 6 frames (0-5)
- Missing assets will use default shapes (not ideal for gameplay)

--- 

This documentation provides the necessary information to understand the project structure, customize the game, and create new levels. For detailed implementation specifics, refer to the `main.py` source code.