# 1942-lite Documentation

## Overview
**1942-lite** is a lightweight, open-source 2D top-down shooter inspired by classic arcade games like *1942*. Built using Python's **Pygame** library, it supports desktop (Windows/macOS/Linux) and web (via **pygbag**) platforms. The game features procedural level generation, power-ups, and cross-platform controls.

---

## Key Features

### Core Gameplay
- **Vertical Scrolling**: Navigate through waves of enemies while collecting power-ups.
- **Power-Ups**:
  - **Health**: Restore player health.
  - **Ammo**: Increase shooting capacity.
  - **Enhanced**: Switch to spread-shot or rapid-fire modes.
  - **Fan**: Enable diagonal movement for agility.
- **Safe Zone**: Reach the bottom of the screen to progress to the next level.

### Cross-Platform Support
- **Desktop**: Keyboard/mouse or WASD controls.
- **Web/Mobile**: Virtual joystick (left) and fire button (right).
- **Portability**: Built with **Pygame** for desktop and **pygbag** for web deployment.

---

## Project Structure

```
1942-lite/
│
├── assets/               # Game assets (optional)
│   ├── background1.png   # Background image
│   └── player.png        # Player sprite
│
├── levels/               # Text-based level definitions
│   └── level1.txt        # Example level layout
│
├── build/                # Web build output (generated)
│   └── web/              # WebAssembly bundle
│
├── README.md             # This documentation
├── main.py               # Game entry point
├── requirements.txt      # Python dependencies
└── build/version.txt     # Version number (0.9.2)
```

---

## Getting Started

### Prerequisites
- Python 3.x installed.
- Basic knowledge of virtual environments.

### Installation
1. **Create a virtual environment**:
   ```bash
   python -m venv venv_1942
   ```

2. **Activate the environment**:
   - Windows:
     ```bash
     venv_1942\Scripts\activate
     ```
   - macOS/Linux:
     ```bash
     source venv_1942/bin/activate
     ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

---

## Playing the Game

### Desktop Controls
| Action       | Key(s)          |
|--------------|-----------------|
| Move         | Arrow Keys / W/A/S/D |
| Shoot        | Space           |
| Pause/Resume | P               |
| Quit         | Esc / Q         |
| Debug Overlay| F1              |

### Web/Mobile Controls
- **Left Thumb**: Virtual joystick (bottom-left).
- **Right Thumb**: Fire button (bottom-right).

---

## Web Deployment (pygbag)

### Build Process
1. **Install pygbag** (if not already installed):
   ```bash
   pip install pygbag
   ```

2. **Build the web bundle**:
   ```bash
   python -m pygbag .
   ```
   This generates a `build/web/` directory with:
   - `index.html` (entry point)
   - WASM runtime
   - Compiled assets

3. **Deploy Static Files**:
   Ensure the following are placed at the same level as `build/web/`:
   ```
   /your-host-root/
     ├─ build/
     │  └─ web/          # Generated web bundle
     ├─ assets/          # Game assets (PNGs)
     └─ levels/          # Level definition files
   ```

4. **Run in Browser**:
   Open `build/web/index.html` in a browser. Use a local HTTP server for testing:
   ```bash
   python -m http.server
   ```

---

## Configuration

### Level Files
- **Location**: `levels/` directory.
- **Format**: Text-based files (e.g., `level1.txt`) defining enemy positions, obstacles, and objectives.
- **Autodiscovery**: The game automatically loads `level*.txt` files.

### Assets
- **Optional**: If `assets/` is missing, the game uses default placeholders.
- **Customization**: Replace `background1.png` and `player.png` for custom visuals.

---

## Technical Details

### Dependencies
- **Pygame**: For desktop rendering and input handling.
- **pygbag**: Converts Pygame apps to WebAssembly for browser deployment.

### Versioning
- **Current Version**: `0.9.2` (see `build/version.txt`).

---

## Usage Examples

### Run Desktop Version
```bash
python main.py
```

### Run with Specific Level
```bash
python main.py --level 3
```

### Build Web Version
```bash
python -m pygbag .
```

---

## Contributing

1. Fork the repository.
2. Create a new branch for your feature/fix.
3. Submit a pull request with detailed changes.

---

## License

**1942-lite** is released under the [MIT License](LICENSE). See `LICENSE` for full terms.

---

## Acknowledgments

- **Pygame**: For 2D game development.
- **pygbag**: For web deployment capabilities.
- **Classic Arcade Games**: Inspiration for gameplay mechanics.