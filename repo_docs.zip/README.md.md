# 1942-lite Shooter Game

A lightweight 2D shooter game inspired by classic arcade titles, featuring player mechanics, enemy AI, power-ups, and level progression.

---

## 📌 Overview

This project is a 2D shooter game built using Python's [Pygame](https://www.pygame.org/) library. It includes:
- Player movement and shooting
- Enemy AI and wave-based combat
- Power-up mechanics (e.g., enhanced fire, diagonal shooting)
- Level progression system
- Safe zone victory condition

The game supports multiple levels, configurable difficulty, and includes a simple HUD for tracking lives, ammo, and power-up timers.

---

## 🧰 Prerequisites

- Python 3.7+
- [Pygame](https://www.pygame.org/) (`pygame>=2.5.2`)
- [Pygbag](https://pygbag.readthedocs.io/) (for web deployment)

---

## 📦 Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

---

## 🕹️ Usage

### Run the Game
```bash
python main.py
```

### Specify a Level
```bash
python main.py --level 3
```

---

## 📁 Project Structure

```
/levels/               # Level files (level1.txt, level2.txt, etc.)
/main.py               # Main game logic
/README.md             # This file
/requirements.txt      # Python dependencies
/build/version.txt     # Version number (0.9.2)
```

---

## 🎮 Key Features

- **Player Controls**: Arrow keys or touch controls (mobile/web)
- **Shooting**: Normal and enhanced fire modes
- **Power-Ups**:
  - `health`: Restore 1 life
  - `ammo`: Add 50 bullets
  - `enhanced`: Temporary rapid-fire mode
  - `fan`: Diagonal shooting for 3 seconds
- **Enemies**: Various types with different behaviors
- **Level System**: Progress through multiple levels
- **Safe Zone**: Victory condition when reaching the bottom of the screen

---

## 🧠 Configuration

### Level Files
- Located in `/levels/`
- Format: `levelX.txt` (e.g., `level1.txt`)
- Define enemy waves, bullet patterns, and level geometry

### Environment Variables
- `LEVELS_DIR`: Directory containing level files (default: `./levels`)

---

## 🧩 Development

### Adding New Levels
1. Create a new `levelX.txt` file in `/levels/`
2. Define enemy spawn patterns and level boundaries

### Contributing
1. Fork the repository
2. Create a new branch for your feature
3. Submit a pull request

---

## 📦 Version
Current version: `0.9.2` (from `build/version.txt`)

---

## 📄 License
This project is open-source and distributed under the MIT License. See the [LICENSE](LICENSE) file for details.