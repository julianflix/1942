# Level File Documentation: `levels/level2.txt`

This file defines the layout of **Level 2** in a grid-based game or simulation. It uses a character-based format to represent entities, obstacles, and terrain. Below is a detailed breakdown of its structure, purpose, and relationships with the broader codebase.

---

## 🧩 File Structure

Each line represents a row in a 40-column grid. The characters correspond to specific elements in the game world:

| Character | Description                     | Example Usage                     |
|-----------|----------------------------------|-----------------------------------|
| `.`       | Empty space / walkable terrain  | Background, paths                 |
| `K`       | Enemy / hostile entity          | Enemies to avoid or defeat        |
| `B`       | Block / obstacle                | Immoveable objects                |
| `S`       | Start position / player spawn   | Initial location for the player   |
| `#`       | Wall / impassable barrier       | Unpassable terrain                |

### Example Row:
```
...................................K....................................
```
- A row with a single `K` (enemy) at column 24.

---

## 📁 Relationship with Codebase

This file is part of a collection of level definitions in the `levels/` directory. The codebase likely uses a function like `discover_levels()` (from `utils.py`) to load and parse these files. For example:

```python
def discover_levels():
    levels = []
    for filename in os.listdir("levels"):
        if filename.startswith("level") and filename.endswith(".txt"):
            with open(f"levels/{filename}") as f:
                grid = [list(line.strip()) for line in f]
                levels.append(grid)
    return levels
```

- **Input**: Text file with 40-character rows.
- **Output**: 2D grid data used to initialize the game world.

---

## 🔧 Configuration Implications

- **Symbol Mapping**: The game engine must map characters (`K`, `B`, `S`, etc.) to specific behaviors. For example:
  - `S` triggers the player's starting position.
  - `K` spawns enemies that move or attack.
- **Level Design**: Each `levelX.txt` file defines unique challenges. For instance:
  - `level2.txt` includes:
    - Multiple `K` enemies (e.g., at column 24 in row 6).
    - `B` blocks (e.g., in row 12).
    - `S` start points (e.g., row 20).

---

## 🧪 Usage Examples

### 1. **Modifying the Level**
To add a new obstacle:
```diff
- ...................................K....................................
+ ...................................B....................................
```
Replace `K` with `B` to turn an enemy into a block.

### 2. **Analyzing the Grid**
Use Python to inspect the level:
```python
with open("levels/level2.txt") as f:
    grid = [list(line.strip()) for line in f]
print(grid[6][24])  # Output: 'K' (enemy at row 6, column 24)
```

### 3. **Testing Load Behavior**
Ensure the file is parsed correctly:
```python
def test_level2():
    with open("levels/level2.txt") as f:
        lines = f.readlines()
    assert len(lines) == 30  # 30 rows
    assert all(len(line.strip()) == 40 for line in lines)  # 40 columns
```

---

## 🧠 Key Observations

- **Consistency**: All level files follow the same 40x30 grid format.
- **Scalability**: New levels can be added by creating `levelX.txt` files.
- **Extensibility**: Additional characters (e.g., `P` for power-ups) can be introduced with corresponding logic.

---

## 📌 Notes

- This format assumes a fixed grid size (30 rows × 40 columns).
- Symbols like `#` (walls) or `S` (start) may vary based on the game's rules.
- Ensure no trailing spaces or formatting issues in the file to avoid parsing errors.

--- 

This documentation provides a clear understanding of how `level2.txt` fits into the broader system, enabling developers to modify or extend levels effectively.